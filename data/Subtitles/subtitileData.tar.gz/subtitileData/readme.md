large.txt: large data set, with 2334320 lines;
small.txt: small data set, with 223364 lines;
smaller.txt: smaller data set, with 17956 lines;
tiny.txt: tiny data set, with 3666 lines for debug.
